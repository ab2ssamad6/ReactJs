const log = message => {
    console.log('Sending to Elastic Search: ', message);
}

export default log;