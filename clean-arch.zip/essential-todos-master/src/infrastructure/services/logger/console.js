const log = console.log;

export default log;