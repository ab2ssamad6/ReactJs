import ui from './ui';
import todos from './todos';

export default [
    ...ui,
    ...todos,
]